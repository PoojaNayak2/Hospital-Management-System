import java.util.Scanner;
class DeQueue{
    static int[] dq;
    static int front=-1,rear=-1,size;
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size : ");
        int n = sc.nextInt();
        create(n);
        System.out.println("Dequeue is ready");

        while (true){
            System.out.println("1. insert Front");
            System.out.println("2. insert rear");
            System.out.println("3. delete Front");
            System.out.println("4. delete rear");
            System.out.println("5. traverse");
            System.out.println("6. exit");

            System.out.println("enter your choice :");

            int choice = sc.nextInt();
            if (choice==1){
                System.out.println("enter element u want to insert from front");
                int ele= sc.nextInt();
                insertFront(ele);
            }
            else if(choice==2){
                System.out.println("enter element u want to insert from rear");
                int ele= sc.nextInt();
                insertFront(ele);
            }
            else if(choice==3){
                deleteFront();
            }
            else if(choice==4)
            {
                deleteRear();
            }
            else if(choice==5)
            {
                traverse();
            }
            else if(choice==6){
                System.out.println("End Of Program");
                break;
            }
            else{
                System.out.println("invalid choice");
            }
        }
        sc.close();
    }
    static void create(int n)
    {
        dq=new int[n];
        size=n;
    }
    static void insertFront(int ele)
    {
        if(isFull()){
            System.out.println("QUeue overflow");
        }
        else
        {
            if(front==-1){
                front=rear=0;
            }
            else if(front==0)
            {
                front=size-1;
            }
            else{
                front--;
            }
            dq[front]=ele;
            System.out.println("element inserted");
        }

    }
    static void deleteFront()
    {
        if(isEmpty()){
            System.out.println("Queue is empty/underflow");
        }
        else{
            System.out.println("element deleted"+dq[front]);
            if(front==rear){
                front=rear=-1;
            }
            else if(front==size-1)
            {
                front=0;
            
            }
            else{
                front++;
            }
        }

    }
    static void insertRear(int ele){
        if(isFull()){
            System.out.println("QUeue overflow");
        }
        else
        {
            if(front==-1){
                front=rear=0;
            }
            else if(rear==size-1)
            {
                rear=0;
            }
            else{
                rear++;
            }
            dq[rear]=ele;
            System.out.println("element inserted ");
        }
    }
    static void deleteRear(){
        if(isEmpty()){
            System.out.println("Queue is empty/underflow");
        }
        else{
            System.out.println("element deleted"+dq[rear]);
            if(front==rear){
                front=rear=-1;
            }
            else if(rear==0)
            {
                rear=size-1;
            
            }
            else{
                rear--;
            }
        }
    }
    static boolean isFull(){
        if((front==0)&&(rear==size-1)|| (front==rear+1))
        {
            return true;
        }
        else{
            return false;
        }
    }
    static boolean isEmpty(){
        if (rear==-1)
            return true;
        else
            return false;
    }
    static void traverse(){
        if(isEmpty()){
            System.out.println("Dequeue is empty");
        }
        else {
            System.out.println("Dequeue elements are");
            if(front<=rear){
                for(int i=front;i<=size-1;i++){
                    System.out.println(dq[i]);
                }
            }
            else{                
                for(int i=0;i<front;i++){
                    System.out.println(dq[i]);
                }
            }
        }
    }
}