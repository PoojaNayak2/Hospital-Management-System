import java.util.Scanner;

public class sumsunc {
    public static void main(String[] args) {
       
        Scanner in = new Scanner(System.in);
        System.out.println("no1: ");
        int num1=in.nextInt();
        System.out.println("no2: ");
        int num2=in.nextInt();
        swap(num1, num2);
        sum(num1,num2);
        in.close();
    }
    static void sum(int n1,int n2)
    {
                int sum=n1+n2;
        System.out.println(sum);

 
    }
    static void swap(int n1,int n2)
    {
        int temp=n1;
        n1=n2;
        n2=temp;
        System.out.println("1st"+ n1);
        System.out.println("2nd"+n2) ;
    }
    
}
