
import java.util.Scanner;
public class pattern31 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("enter n:");
        int n=in.nextInt();
        int num=n;
        n=(n*2)-1;
        
        for(int i=0 ;i<=n;i++)
        {
            for(int j=0;j<=n;j++)
            {
                int up=i;
                int down=n-i;
                int left=j;
                int right=n-j;
                int m= num-(Math.min(Math.min(up,down) , Math.min(left,right)));
                System.out.print(m+" ");
            }
            System.out.println();
        }
        in.close();
    }
}

