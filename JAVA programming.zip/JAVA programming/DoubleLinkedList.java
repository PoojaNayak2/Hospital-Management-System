import java.util.Scanner;

public class DoubleLinkedList {
    
    static Node root = null;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("1. Append");
            System.out.println("2. Display");
            System.out.println("3. Length of list");
            System.out.println("4. Add first");
            System.out.println("5. Add after");
            System.out.println("6. Search");
            System.out.println("7. Delete first");
            System.out.println("8. Delete After");
            System.out.println("9. Swap elements");
            System.out.println("10. Exit");

            System.out.println("Enter a choice : ");
            int ch = sc.nextInt();

            if (ch == 1) {
                System.out.println("Enter element to add: ");
                int ele = sc.nextInt();
                append(ele);
            } 
            else if (ch == 2) {
                display();
            } 
            else if (ch == 3) {
                int len = length();
                System.out.println("List length is : " + len);
            } 
            else if (ch == 4) {
                System.out.println("Enter element to add at first");
                int ele = sc.nextInt();
                addFirst(ele);
            } 
            else if (ch == 5) {
                System.out.println("Enter element to add at particular location");
                int ele = sc.nextInt();
                System.out.println("Enter location");
                int loc = sc.nextInt();
                addAfter(ele, loc);
            } 
            else if (ch == 6) {
                System.out.println("Enter element to search:");
                int ele = sc.nextInt();
                search(ele);
            } 
            else if (ch == 7) {
                deleteFirst();
            } 
            else if (ch == 8) {
                System.out.println("Enter location at which you want to delete: ");
                int loc = sc.nextInt();
                deleteAfter(loc);
            } 
            else if (ch == 9) {
                System.out.println("Enter locations to swap: ");
                int loc1 = sc.nextInt();
                int loc2 = sc.nextInt();
                swap(loc1, loc2);
            } 
            else if (ch == 10) {
                System.out.println("Exit program ");
                break;
            } else {
                System.out.println("Invalid choice");
            }
        }
        sc.close();
    }
    static void append(int ele) {
        Node temp = new Node();
        if (root == null) {
            root = temp;
        } 
        else 
        {
            Node last = root;
            while (last.next != null) 
            {
                last=last.next;
            }
            last.next=temp;
            temp.prev=last;
        }
        System.out.println("appended to list ");
    }

    static void display() {
        if (root == null) {
            System.out.println("List is empty");
        } else {
            System.out.println("List is: ");
            Node temp = root;
            while (temp != null) {
                System.out.println(temp.data);
                temp = temp.next;
            }
        }
    }

    static int length() {
        Node temp = root;
        int count = 0;
        while (temp != null) {
            count++;
            temp = temp.next;
        }
        return count;
    }

    static void addFirst(int ele) {
        Node temp = new Node();
        if (root == null) {
            root = temp;
        } else {
            temp.next = root;
            root.prev = temp;
            root = temp;
        }
    }

    static void addAfter(int ele, int loc) {
        Node target = new Node();
        int len = length();
        if (loc > 0 && loc <= len) {
            Node temp = root;
            for (int i = 1; i < loc; i++) {
                temp = temp.next;
            }
            target.next = temp.next;
            if (temp.next != null) {
                temp.next.prev = target;
            }
            temp.next = target;
            target.prev = temp;
        } else {
            System.out.println("invalid location, list has only " + len + " nodes.");
        }
    }

    static void search(int ele) {
        Node temp = root;
        boolean found = false;
        while (temp != null) {
            if (temp.data == ele) {
                System.out.println(ele + " found ");
                found = true;
                break;
            }
            temp = temp.next;
        }
        if(!found) {
            System.out.println("Element not found");
        }
    }
    static void deleteFirst() {
        if (root == null) {
            System.out.println("List is empty");
        } else {
            Node temp = root;
            root = root.next;
            if (root != null) {
                root.prev = null;
            }
            temp.next = null; 
        }
    }
    static void deleteAfter(int loc) {
        int len = length();
        if (loc>=1 && loc<len) {
            Node temp=root;
            for (int i=1; i<loc; i++) {
                temp=temp.next;
            }
            Node target = temp.next;
            temp.next = target.next;
            if (target.next != null) {
                target.next.prev = temp;
            }
            target.prev = null; 
            target.next = null; 
        } else {
            System.out.println("Invalid location ");
        }
    }

    static void swap(int loc1, int loc2) {
        int len = length();
        if (loc1<len && loc1>=1 && loc1<loc2 && loc2<=len) {
            Node node1 = getNodeAt(loc1);
            Node node2 = getNodeAt(loc2);
            int temp = node1.data;
            node1.data = node2.data;
            node2.data = temp;
            System.out.println("Swapping done");
        } 
        else {
            System.out.println("Invalid locations given");
        }
    }

    static Node getNodeAt(int loc) {
        Node temp = root;
        for (int i = 1; i < loc; i++) {
            temp = temp.next;
        }
        return temp;
    }
}


class Node {
    int data;
    Node prev;
    Node next;

    
}

