import java.util.Scanner;
public class linkedList {
    static Node root=null;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        while(true){
            System.out.println("1. Append");
            System.out.println("2. Display");
            System.out.println("3. Length of list");
            System.out.println("4. Add first");
            System.out.println("5. Add after");
            System.out.println("6. Search");
            System.out.println("7. Delete first");
            System.out.println("8. Delete After");
            System.out.println("9. swap elements");
            System.out.println("10. Exit");

            System.out.println("Enter a choice : ");
            int ch=sc.nextInt();

            if (ch==1){
                System.out.println("Enter elememt to add: ");
                int ele=sc.nextInt();
                append(ele);
            }
            else if(ch==2){
                display();
            }
            
            else if (ch==3){
                int len=length();
                System.out.println("list length is : "+len);
            }
            else if(ch==4){
                System.out.println("enter element to add at first");
                int ele=sc.nextInt();
                AddFirst(ele);
            }
            else if(ch==5){
                System.out.println("enter element to add at particular location");
                int ele=sc.nextInt();
                System.out.println("enter location");
                int loc=sc.nextInt();
                AddAfter(ele,loc);
            }
            else if(ch==6){
                System.out.println("enter element to search:");
                int ele=sc.nextInt();
                search(ele);
            }
            else if(ch==7){
                deleteFirst();
            }
            else if(ch==8){
                System.out.println("Enter location at which you want to enter: ");
                int loc=sc.nextInt();
                deleteAfter(loc);
            }
            else if(ch==9)
            {
                System.out.println("enter locations to swap: ");
                int loc1=sc.nextInt();
                int loc2=sc.nextInt();
                swap(loc1, loc2);
            }

            else if(ch==10){
                System.out.println("Exit program ");
                break;
            }
            else
            {
                System.out.println("invalid choice");
            }
        }
        sc.close();
      
        }
        static void append(int ele)
        {
            Node temp=new Node();
            temp.data=ele;
            if(root==null){
                root=temp;
            }
            else{
                Node last=root;
                while(last.link!=null){
                    last=last.link;
                }
                last.link=temp;

            }
            System.out.println("appended to list ");
    }
    static void display(){
        if(root==null){
            System.out.println("list is empty");
        }
        else{
            System.out.println("list is: ");
            Node temp=root;
            while(temp!=null){
                System.out.println(temp.data);
                temp=temp.link;
            }
        }
    }
    static int length(){
        Node temp=root;
        int count=0;
            while(temp!=null){
                count++;               
                temp=temp.link;
            }
        return count;
    }
    static void AddFirst(int ele){
        Node temp=new Node();
        temp.data=ele;
        temp.link=root;
        root=temp;
    }
    static void AddAfter(int ele,int loc){
        Node temp=new Node();
        temp.data=ele;

        int len=length();
        if (loc>0&&loc<len)
        {
            int i=1;
            Node t=root;
            while(i<loc){
                t=t.link;
                i++;
            }
            temp.link=t.link;
            t.link=temp;

        }
        else{
            System.out.println("invald location, list has only "+ len+ "nodes.");
        }
        
    }
    static void search(int ele){
        Node temp=root;
        boolean found=false;
        while(temp!=null){
        if(temp.data==ele)
        {
            System.out.println(ele+" found ");
            found=true;
            break;
        }
        //System.out.println(temp.data);
                temp=temp.link;
            }
            if(!found){
                System.out.println("element not found");
            }
    }
    static void deleteFirst(){
        if(root==null)
        {
            System.out.println("list is empty");
        }
        else{
            Node temp=new Node();
            root=root.link;
            temp.link=null;

        }
    }
    static void deleteAfter(int loc){
        int len=length();
        if(loc>=1 && loc<len)
        {
            int i=1;
            Node p=root;
            while(i<loc){
                p=p.link;
                i++;
            }
            Node q=p.link;
            p.link=q.link;
            q.link=null;
            /*q=null
             * System.gc(); -----garbage value collector
             */
        }
        else{

            System.out.println("invalid loc given");
        }
    }
    static void swap(int loc1,int loc2){
        int len=length();
        if(loc1<len && loc1>=1 && loc1<loc2 && loc2<=len)
        {
            int i =1,j=1;
            Node p=root;
            Node q=root;
            while(i<loc1){
                p=p.link;
                i++;
            }
            while(j<loc2){
                q=q.link;
                j++;
            }
            int temp=p.data;
            p.data=q.data;
            q.data=temp;

            System.out.println("swapping done");

        }
    }
}

class Node{
    int data; 
    Node link;
}
