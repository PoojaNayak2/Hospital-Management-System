package DSAwithJava;

public class HasA {
    public static void main(String args[]) {
    //Employee emp = new Employee(101, "Pooja", 120);
    //Address addr = new Address("50", "JSR", "Jharkhand");
    //emp.addr = addr;
    
    System.out.println("Employee Details: " );
    System.out.println("Address Details: " );
    }
}
    
