public class Main {
    public static void main(String[] args) {
        Employee emp=new Employee(1,"Pooja",50000);
        Address addr=new Address("80", "JSR", "JHAR");
        System.out.println("details of employee : "+emp);
        System.out.println("details of employee : "+addr);

    }
}
class Employee
{
    int id, salary;
    String name;
    Employee(int id, String name,int salary)
    {
        this.id=id;
        this.name=name;
        this.salary=salary;
    }
    public String toString() 
    {
        return "ID: " + this.id + ", Name: " + this.name + ", Salary: " + this.salary;
}

}
class Address{
    String street,city,state;
    Address(String street,String city, String state){
        this.state=state;
        this.city=city;
        this.street=street;
    }
    public String toString(){
        return "Street: "+this.street+",City: "+this.city+", State :"+this.state;
    }
}
