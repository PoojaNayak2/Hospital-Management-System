import java.util.Scanner;

public class InfixToPostfixConverter {
    static char infix[];
    static char stack[];
    static char postfix[];
    static int top;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char ch;

        do {
            top = -1;
            System.out.print("\nEnter an Infix expression: ");
            infix = scanner.nextLine().toCharArray();
            postfix = new char[infix.length];
            stack = new char[infix.length]; // Initialize the stack array
            InfixToPostfix();
            System.out.print("Postfix expression is: ");
            for (int i = 0; i < postfix.length; i++) {
                System.out.print(postfix[i]);
            }
            System.out.print("\nDo you want to convert one more(y/n): ");
            ch = scanner.next().charAt(0);
            scanner.nextLine(); // Consume newline
        } while (ch == 'y');

        scanner.close();
    }

    public static void InfixToPostfix() {
        int i, p, l, type, prec;
        char next;
        i = p = 0;
        l = infix.length;

        while (i < l) {
            type = getType(infix[i]);
            switch (type) {
                case LP:
                    push(infix[i]);
                    break;
                case RP:
                    while ((next = pop()) != '(') {
                        postfix[p] = next;
                        p++;
                    }
                    break;
                case OPERAND:
                    postfix[p] = infix[i];
                    p++;
                    break;
                case OPERATOR:
                    prec = getPrecedence(infix[i]);
                    while (top > -1 && prec <= getPrecedence(stack[top])) {
                        postfix[p] = pop();
                        p++;
                    }
                    push(infix[i]);
                    break;
            }
            i++;
        }

        while (top > -1) {
            postfix[p] = pop();
            p++;
        }
    }

    public static int getType(char sym) {
        switch (sym) {
            case '(':
                return LP;
            case ')':
                return RP;
            case '+':
            case '-':
            case '*':
            case '/':
            case '%':
                return OPERATOR;
            default:
                return OPERAND;
        }
    }

    public static int getPrecedence(char sym) {
        switch (sym) {
            case '(':
                return LPP;
            case '+':
                return AP;
            case '-':
                return SP;
            case '*':
                return MP;
            case '/':
                return DP;
            case '%':
                return REMP;
            default:
                return NONE;
        }
    }

    public static void push(char sym) {
        top++;
        stack[top] = sym;
    }

    public static char pop() {
        char sym = stack[top];
        top--;
        return sym;
    }

    // Constants
    static final int LP = 10;
    static final int RP = 20;
    static final int OPERATOR = 30;
    static final int OPERAND = 40;
    static final int LPP = 0;
    static final int AP = 1;
    static final int SP = 1;
    static final int MP = 2;
    static final int DP = 2;
    static final int REMP = 2;
    static final int NONE = 9;
}