import java.util.Scanner;

public class stack_LinkkedList {
    static Node top=null;

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        while(true){
            System.out.println("1. push");
            System.out.println("2. pop");
            System.out.println("3. peek");
            System.out.println("4. display");
            System.out.println("5. Exit");

            System.out.println("Enter a choice : ");
            int ch=sc.nextInt();

            if (ch==1){
                System.out.println("enter element to push : ");
                int ele=sc.nextInt();
                push(ele);

            }
            else if(ch==2){
                pop();
            }
            else if(ch==4){
                display();
            }
            else if(ch==3){
                peek();
            }
            else if(ch==5){
                System.out.println("Exit program ");
                break;   
            }
            else{
                System.out.println("invalid choice");

            }

    }
    sc.close();
}

static void push(int ele){
    Node temp=new Node();
    temp.data=ele;
    temp.link=top;
    top=temp;
}
static void pop(){
    if(top==null)
    {
        System.out.println("stack is empty");
    }
    else{
        Node temp = top;
        System.out.println("popped element : "+ top.data);
        top=top.link;
        top=top.link;
        temp.link=null;
    }
}
static void peek(){
    if(top==null){
        System.out.println("stack is empty");
    }
    else{
        Node temp=top;
        int ele=0;
        while(temp!=null){
           ele=temp.data;
            temp=temp.link;
        }
        System.out.println("top element"+ele);
    }
}
static void display(){
    if(top==null){
        System.out.println("stack is empty");
    }
    else{
        System.out.println("stack is: ");
        Node temp=top;
        while(temp!=null){
            System.out.println(temp.data);
            temp=temp.link;
        }
    }
}

}

class Node{
    int data; 
    Node link;
}
