import java.util.Scanner;
public class pattern2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("enter n:");
        int n=in.nextInt();
        for(int i=1;i<=2*n;i++)
        {
            int col=i<n?i:2*n-i;
            int spaces=n-col;
            for(int s=1;s<=spaces;s++)
            {
                System.out.print(" ");
            }
            for(int j=0;j<col;j++)
            {
                System.out.print("* ");
            }
            System.out.println();
            
        }
        in.close();
    }
}

