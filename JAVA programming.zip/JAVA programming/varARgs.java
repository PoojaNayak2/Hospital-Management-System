import java.util.Arrays;

public class varARgs {
    public static void main(String[] args) {
        sum(2,3,5);
        fun(2,5,"poo","na");
    }

        static void sum(int ...v)
        {
            System.out.println(Arrays.toString(v));
        }
        static void fun(int a, int b,String ...v){
            System.out.println();
        }
    }

