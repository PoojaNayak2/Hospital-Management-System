import java.util.Scanner;

public class CQueueDS {


    static int cq[];
    static int front=-1;
    static int rear=-1;
    static int size;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size : ");
        int n = sc.nextInt();
        create(n);
        System.out.println("Cquee is ready");

        while(true){
            System.out.println("1. insert");
            System.out.println("2. delete");
            System.out.println("3. display");
            System.out.println("4. traverse");
            System.out.println("5. exit");

            System.out.println("enter your choice :");

            int choice = sc.nextInt();

            if(choice==1){
                System.out.println("enter element u want to push");
                int ele= sc.nextInt();
                insert(ele);
            } else if (choice==2) {
                delete();
            } else if (choice==3) {
                traverse();
            } else if (choice==4) {
                didplay();
            } else if (choice==5) {
                System.out.println("End Of Program");
                break;
            }else {
                System.out.println("Invalid Choice");
            }
        }
        sc.close();
    }
    static void create(int n){

        cq= new int[n];
        size=n;
    }
    static void insert(int ele){
        if(isFull()){
            System.out.println("Quee is overflow");
        }
        else{
            if(front==-1){
                front=rear=0;
            } else if (rear==size-1) {
                rear=0;
            }else{
                rear++;
            }
        }
        cq[rear]=ele;
        System.out.println("inserted");
    }
    static void delete(){
        if(isEmpty()){
            System.out.println("Quee is underflow");
        }
        else{
            System.out.println(cq[front]);
            if(front==rear){
                front=rear=-1;
            } else if (rear==size-1) {
                front=0;
            }else{
                front++;
            }
        }
    }
    static void traverse(){
        if(isEmpty()){
            System.out.println("quee is empty");
        }
        else {
            System.out.println("quee elements are");
            if(front<=rear){
                for(int i=front;i<=rear;i++){
                    System.out.println(cq[i]);
                }
            }else{
                for(int i=0;i<front;i++){
                    System.out.println(cq[i]);
                }
            }
        }
    }
    static void didplay(){
        if(front<=rear){
            for(int i=front;i<rear;i++){
                System.out.println(cq[i]);
            }
        }else{
            for(int i=front;i<rear;i++){
                System.out.println(cq[i]);
            }
            for(int i=0;i<front;i++){
                System.out.println(cq[i]);
            }
        }
    }
    static boolean isFull(){
        if ((front==0 && rear==size-1) || (front==rear+1)){
            return true;
        }else{
            return false;
        }
    }
    static boolean isEmpty(){
        if (rear==-1){
            return true;
        }else{
            return false;
        }
    }
}

