
import java.util.Scanner;

public class infixtoprefix {
    static char infix[];
    static char stack[];
    static char prefix[];
    static int top;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char ch;       

        do {
            top = -1;
            System.out.print("\nEnter an Infix expression: ");
            infix = scanner.nextLine().toCharArray();
            prefix = new char[infix.length];
            stack = new char[infix.length]; // Initialize the stack array
            infixToPrefix();
            System.out.print("Prefix expression is: ");
            for (int i = 0; i < prefix.length; i++) {
                System.out.print(prefix[i]);
            }
            System.out.print("\nDo you want to convert one more(y/n): ");
            ch = scanner.next().charAt(0);
            scanner.nextLine(); // Consume newline
        } while (ch == 'y');

        scanner.close();
    }

    public static void infixToPrefix() {
        reverseInfix(); // Reverse the infix expression
        int i, p, l, type, prec;
        char next;
        i = p = 0;
        l = infix.length;

        while (i < l) {
            type = getType(infix[i]);
            switch (type) {
                case LP:
                    push(infix[i]);
                    break;
                case RP:
                    while ((next = pop()) != '(') {
                        prefix[p] = next;
                        p++;
                    }
                    break;
                case OPERAND:
                    prefix[p] = infix[i];
                    p++;
                    break;
                case OPERATOR:
                    prec = getPrecedence(infix[i]);
                    while (top > -1 && prec <= getPrecedence(stack[top])) {
                        prefix[p] = pop();
                        p++;
                    }
                    push(infix[i]);
                    break;
            }
            i++;
        }

        while (top > -1) {
            prefix[p] = pop();
            p++;
        }
        reversePrefix(); // Reverse the prefix expression to get the final result
    }

    // Method to reverse the infix expression
    public static void reverseInfix() {
        int left = 0;
        int right = infix.length - 1;
        while (left < right) {
            char temp = infix[left];
            infix[left] = infix[right];
            infix[right] = temp;
            left++;
            right--;
        }
    }

    // Method to reverse the prefix expression
    public static void reversePrefix() {
        int left = 0;
        int right = prefix.length - 1;
        while (left < right) {
            char temp = prefix[left];
            prefix[left] = prefix[right];
            prefix[right] = temp;
            left++;
            right--;
        }
    }

    public static int getType(char sym) {
        switch (sym) {
            case '(':
                return LP;
            case ')':
                return RP;
            case '+':
            case '-':
            case '*':
            case '/':
            case '%':
                return OPERATOR;
            default:
                return OPERAND;
        }
    }

    public static int getPrecedence(char sym) {
        switch (sym) {
            case '(':
                return LPP;
            case '+':
                return AP;
            case '-':
                return SP;
            case '*':
                return MP;
            case '/':
                return DP;
            case '%':
                return REMP;
            default:
                return NONE;
        }
    }

    public static void push(char sym) {
        top++;
        stack[top] = sym;
    }

    public static char pop() {
        char sym = stack[top];
        top--;
        return sym;
    }

    // Constants
    static final int LP = 10;
    static final int RP = 20;
    static final int OPERATOR = 30;
    static final int OPERAND = 40;
    static final int LPP = 0;
    static final int AP = 1;
    static final int SP = 1;
    static final int MP = 2;
    static final int DP = 2;
    static final int REMP = 2;
    static final int NONE = 9;
}
